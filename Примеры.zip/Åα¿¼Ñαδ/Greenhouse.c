float pi = 3.141592653589793;

float UVA_RESPONSE;
float UVB_RESPONSE;
int blue;
int bright;
int fan;
int green;
int humidity;
int light;
int matrix_1[4];
int moisture;
int pressure;
int pump;
int red;
int soil;
int temperature;
int uva;
int uvb;
int uvi;
int window;

int main()
{
	
	wifi_connect("Network", "password");
	
	blynk_authorization("token");
	
	UVA_RESPONSE = 0.001461;
	UVB_RESPONSE = 0.002591;
	while (1) {
		uva = getdigsensor(UVA_ULTRAVIOLET, { D22, D21 });
		uvb = getdigsensor(UVB_ULTRAVIOLET, { D22, D21 });
		
		uvi = round((uva * UVA_RESPONSE + uvb * UVB_RESPONSE) / 2);
		blynk_send(V11, uva);
		
		blynk_send(V12, uvb);
		
		blynk_send(V13, uvi);
		
		light = getdigsensor(LIGHT, { D22, D21 });
		
		blynk_send(V17, light);
		
		pressure = getdigsensor(PRESSURE, { D22, D21 });
		
		blynk_send(V16, pressure);
		
		temperature = getdigsensor(HEATING, { D22, D21 });
		
		blynk_send(V14, temperature);
		
		humidity = getdigsensor(HUMIDITY, { D22, D21 });
		
		blynk_send(V15, humidity);
		
		moisture = getansensor(SOIL, A6);
		
		blynk_send(V9, moisture);
		
		soil = getansensor(TEMPERATURE, A7);
		
		blynk_send(V7, soil);
		
		fan = blynk_receive(V5);
		
		setvoltage(D16, fan);
		
		pump = blynk_receive(V6);
		
		setvoltage(D17, pump);
		
		window = blynk_receive(V0);
		
		setmotor(D19, window);
		
		red = blynk_receive(V1);
		
		green = blynk_receive(V2);
		
		blue = blynk_receive(V3);
		
		bright = blynk_receive(V4);
		
		matrix_1[0] = '\0';
		matrix_1[1] = red * bright / 100;
		matrix_1[2] = green * bright / 100;
		matrix_1[3] = blue * bright / 100;
		setsignal(MATRIX, { D18 }, matrix_1);
		
		t_sleep(500);
		
	}
	return 0;

}
